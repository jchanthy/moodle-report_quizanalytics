// This file is part of Moodle - http://moodle.org/
//
// Moodle is free software: you can redistribute it and/or modify
// it under the terms of the GNU General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
//
// Moodle is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU General Public License for more details.
//
// You should have received a copy of the GNU General Public License
// along with Moodle.  If not, see <http://www.gnu.org/licenses/>.

/**
 * Client-side chart and UI helper for report_quizanalytics.
 *
 * @module     report_quizanalytics/charts
 * @copyright  2026
 * @license    http://www.gnu.org/copyleft/gpl.html GNU GPL v3 or later
 */
define([], function() {
    'use strict';

    return {
        /**
         * Initialize export field select all/none buttons.
         */
        init: function() {
            var selectAll = document.getElementById('btn-select-all');
            var deselectAll = document.getElementById('btn-deselect-all');

            if (selectAll) {
                selectAll.addEventListener('click', function() {
                    var checkboxes = document.querySelectorAll('.export-field');
                    checkboxes.forEach(function(cb) {
                        cb.checked = true;
                    });
                });
            }

            if (deselectAll) {
                deselectAll.addEventListener('click', function() {
                    var checkboxes = document.querySelectorAll('.export-field');
                    checkboxes.forEach(function(cb) {
                        cb.checked = false;
                    });
                });
            }
        }
    };
});
